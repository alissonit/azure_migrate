# Azure-migrate 

This is a module to management Azure migrate based on REST API
[Docs Azure REST API](https://docs.microsoft.com/en-us/rest/api).

